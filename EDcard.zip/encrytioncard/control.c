#include <stdio.h>
#include <linux/ioctl.h>
#include <fcntl.h>
#include "char_multi_dev.h"

int main()
{
    
    int cmd;
    unsigned char buff[16];
    printf("migrate start input:0\nmigrate end input:1\nmigtate state save:2\n");
    printf("reset:3\n");

    while(1)
    {
        scanf("%d", &cmd);
        
        int fd = open("/dev/multi_dev0", O_RDWR);
        switch(cmd)
        {
            case 0:
                ioctl(fd, MIGRATE_START);
                break;
            case 1:
                ioctl(fd, MIGRATE_END);
                break;
            case 2:
                
                ioctl(fd, MIGRATE_STATE_SAVE, buff);
                
                printf("the state is:");
                int i;
                for(i=0; i<16; i++)
                    printf("%2.x", buff[i]);
                printf("\n");
                break;
            case 3:
                ioctl(fd, RESET);
                break;

            default :
                return 0;
        }
    }
    
    return 0;
}