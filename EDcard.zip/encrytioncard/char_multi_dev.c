#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/init.h>
#include <linux/fs.h>
#include <linux/cdev.h>
#include <asm/uaccess.h>
#include <linux/device.h>
#include <linux/string.h>
#include <linux/wait.h>
#include <linux/ioctl.h>
#include <linux/uaccess.h>
#include <linux/slab.h>
#include "char_multi_dev.h"
#include "aes.h"

#define MAXBUFFLENG 7168

#define MOD_CBC  0x00
#define MOD_ECB  0x01
#define ENC     0X00
#define DEC     0x01

#define IN      1
#define OUT     0

 
MODULE_LICENSE ("GPL");

 
int edcard_major       = 234;
int edcard_minor       = 0;
int number_of_devices = 6;
struct class *dev_class;


//加密卡的结构体
struct edcard_device
{
    struct cdev cdev;
    
    unsigned char iv[16];
    unsigned char key[16];
    unsigned char *data;	 
    int migrate;
    int status;
    wait_queue_head_t wait;

     
} edcard_device[6];
 
 
static int edcard_open (struct inode *inode, struct file *filp)
{
    struct edcard_device *dev = container_of(inode->i_cdev, struct edcard_device, cdev); 
    filp->private_data = dev;

    return 0;
}
 
static int edcard_release (struct inode *inode, struct file *filp)
{
    return 0;
}
 
ssize_t edcard_read (struct file *filp, char *buff, size_t count, loff_t *offp)
{
    ssize_t result = 0;
    struct edcard_device *dev = filp->private_data;
 
    if (count < 0) return -EINVAL;
    //if (count > 127) count = 127;
    if (copy_to_user(buff, dev->data, count)) 
    {
        result = -EFAULT;
    }
    else
    {
	  dev -> status = OUT;
	  printk (KERN_INFO "read %d bytes\n", (int)count);
        result = count;
    }
 
    return result;
}
 

ssize_t edcard_write(struct file *filp, const char *buf, size_t count, loff_t *f_pos)
{
    ssize_t ret = 0; 
    unsigned char data[MAXBUFFLENG+128] = {0};
    unsigned char in[MAXBUFFLENG+1] = {0};

    struct edcard_device *dev = filp->private_data;

    wait_event_interruptible_timeout(dev->wait, dev->migrate == 0, 100000000); 

    printk (KERN_INFO "Writing %d bytes\n", (int)count);
    //if (count > 127) return -ENOMEM;
    if (count < 0) return -EINVAL;
    if (copy_from_user(data, buf, (int)count)) {
        ret = -EFAULT;
    }
    else {
	  dev -> status = IN;
        ret = count;

        if(data[0] == MOD_CBC)
        {
            memcpy(dev->iv, data+2, 16);
            memcpy(in, data+2+16, MAXBUFFLENG);

            if(data[1] == ENC)
            {
                AES128_CBC_encrypt_buffer(dev->data, in, MAXBUFFLENG, dev->key, dev->iv);
            }
            if(data[1] == DEC)
            {
                AES128_CBC_decrypt_buffer(dev->data, in, MAXBUFFLENG, dev->key, dev->iv);
            }
            
        }

        if(data[0] == MOD_ECB)
        {
            memcpy(in, data+2, MAXBUFFLENG);
            
            if(data[1] == ENC)
            {
                AES128_ECB_encrypt(in, MAXBUFFLENG, dev->key, dev->data);
            }
            if(data[1] == DEC)
            {
                AES128_ECB_decrypt(in, MAXBUFFLENG, dev->key, dev->data);
            }
 
        }
     
    }
    return ret;
}


long edcard_ioctl(struct file *filp, unsigned int cmd, unsigned long arg)
{
    struct edcard_device *dev = filp->private_data;
    
    switch(cmd)
    {
        case MIGRATE_START:
            dev->migrate = 1;
            return 0;
        case MIGRATE_STATE_SAVE:
            copy_to_user((unsigned char *)arg, dev->key, 16);
		copy_to_user((unsigned char *)arg+16, dev->iv, 16);
            return 0;
        case MIGRATE_STATE_LOAD:
            copy_from_user(dev->key, (unsigned char*)arg, 16);
		copy_from_user(dev->iv, (unsigned char*)arg+16, 16);
            return 0;
        case MIGRATE_END:
            dev->migrate = 0;
            wake_up(&dev->wait);
            return 0;
	  	case KEY_IMPORT:
            copy_from_user(dev->key, (unsigned char*)arg, 16);
            int i=0;
            printk(KERN_INFO"key:");
            for(;i<16;i++)
                printk(KERN_INFO"dev->key[i]");
            printk("\n");
            return 0;
        case RESET:
            memset(dev->data, 0, MAXBUFFLENG);
            memset(dev->iv, 0, 16);
            memset(dev->key, 0, 16);
            dev->migrate = 0;
            dev->status = 0;
            return 0;
        default: 
            return -EINVAL;
    }
}

struct file_operations edcard_fops = {
    .owner = THIS_MODULE,
    .open  = edcard_open,
    .release = edcard_release,
    .read  = edcard_read,
    .write = edcard_write,
    .unlocked_ioctl = edcard_ioctl,
};
 
static void char_reg_setup_cdev(struct cdev *cdev, dev_t devno)
{
    int error;
 
    cdev_init (cdev, &edcard_fops);//将自定义的操作函数赋予设备
    cdev->owner = THIS_MODULE;
    error = cdev_add (cdev, devno , 1);
    if (error)
        printk (KERN_NOTICE "Error %d adding char_reg_setup_cdev", error);
}
 
static int __init edcard_2_init (void)
{
	printk("edcard init\n");
	int result;
	dev_t devno;

	devno = MKDEV (edcard_major, edcard_minor);
	result = register_chrdev_region (devno, number_of_devices, "edcard_multi");

	if (result < 0) {
	printk (KERN_WARNING "edcard: can't get major number %d\n", edcard_major);
	return result;
	}
	dev_class = class_create(THIS_MODULE,"multi_dev_class");
	if(IS_ERR(dev_class)) 
	{
	printk("Err: failed in creating class.\n");
	return -1; 
	}


	device_create(dev_class,NULL, devno, NULL, "edcard_dev0");
	device_create(dev_class,NULL, devno + 1, NULL, "edcard_dev1");
	device_create(dev_class,NULL, devno + 2, NULL, "edcard_dev2");
	device_create(dev_class,NULL, devno + 3, NULL, "edcard_dev3");
	device_create(dev_class,NULL, devno + 4, NULL, "edcard_dev4");
	device_create(dev_class,NULL, devno + 5, NULL, "edcard_dev5");

	int i;
	for(i = 0; i < number_of_devices; i++)
	{
		char_reg_setup_cdev(&edcard_device[i].cdev, devno+i);
		edcard_device[i].migrate = 0;
		edcard_device[i].data=(unsigned char*)kzalloc(MAXBUFFLENG,GFP_KERNEL);
		memset(edcard_device[i].key,0,16);
		memset(edcard_device[i].iv,0,16);
		init_waitqueue_head(&edcard_device[i].wait);
	}


	printk (KERN_INFO "char device registered\n");

	return 0;
}
 
static void __exit edcard_2_exit (void)
{
	dev_t devno = MKDEV (edcard_major, edcard_minor);

	cdev_del (&edcard_device[0].cdev);
	cdev_del (&edcard_device[1].cdev);
	cdev_del (&edcard_device[2].cdev);
	cdev_del (&edcard_device[3].cdev);
	cdev_del (&edcard_device[4].cdev);
	cdev_del (&edcard_device[5].cdev);
	device_destroy(dev_class, devno);         // delete device node under /dev//必须先删除设备，再删除class类
	device_destroy(dev_class, devno + 1);     // delete device node under /dev//必须先删除设备，再删除class类
	device_destroy(dev_class, devno + 2);     // delete device node under /dev//必须先删除设备，再删除class类
	device_destroy(dev_class, devno + 3);

	device_destroy(dev_class, devno + 4);

	device_destroy(dev_class, devno + 5);

	class_destroy(dev_class);                 

	unregister_chrdev_region (devno, number_of_devices);
	printk("char device exited\n");
}
 
module_init (edcard_2_init);
module_exit (edcard_2_exit);
