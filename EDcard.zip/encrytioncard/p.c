#include<stdio.h>
#include<string.h>
#define SIZE 7168
#define NUM 1
int main()
{
	FILE* fp=fopen("plain","w+");
	char* buf[SIZE];
	memset(buf,0x41,SIZE);
int i;
for(i=0;i<NUM;i++)
	fwrite(buf,1,SIZE,fp);
	fclose(fp);
	return 0;
}
